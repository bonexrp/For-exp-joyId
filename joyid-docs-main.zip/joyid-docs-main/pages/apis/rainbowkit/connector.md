# JoyIdConnector

`@joyid/rainbowkit` re-exports `JoyIdConnector` from `@joyid/wagmi`.

See `@joyid/evm`'s [JoyIdConnector](/apis/wagmi/connector) for more details.

## Implementation

```ts
export { JoyIdConnector } from '@joyid/wagmi'
```
