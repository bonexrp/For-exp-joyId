# logout

Disconnect JoyID and clear the connection status from local storage.

## Types

```ts
function logout(): void
```
