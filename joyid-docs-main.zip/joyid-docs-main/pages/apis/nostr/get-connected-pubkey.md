# getConnectedPubkey

Get public key of connected nostr account from local storage.

## Types

```ts
function getConnectedPubkey(): string | null
```
